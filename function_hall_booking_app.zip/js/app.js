const halls=[
 {id:"royal",name:"Royal Grand Hall",capacity:800,price:50000,chairs:1000,available:true},
 {id:"pearl",name:"Pearl Function Hall",capacity:500,price:32000,chairs:650,available:true},
 {id:"garden",name:"Garden Celebration Hall",capacity:300,price:22000,chairs:400,available:true}
];
const chairRate=50;
const money=n=>"₹"+Number(n).toLocaleString("en-IN");
const $=id=>document.getElementById(id);

function renderHalls(){
 $("hallCards").innerHTML=halls.map(h=>`<article class="card">
   <span class="badge">${h.available?"Available":"Booked"}</span>
   <h3>${h.name}</h3><p>Capacity: ${h.capacity} guests</p>
   <p>Chairs available: ${h.chairs}</p><p class="price">${money(h.price)}</p>
   <button class="btn" onclick="chooseHall('${h.id}')">Select Hall</button>
 </article>`).join("");
 $("hall").innerHTML='<option value="">Select a hall</option>'+halls.filter(h=>h.available).map(h=>`<option value="${h.id}">${h.name} — ${money(h.price)}</option>`).join("");
}
function chooseHall(id){$("hall").value=id; update();location.hash="booking";}
function update(){
 const h=halls.find(x=>x.id===$("hall").value);
 const chairs=Number($("chairs").value)||0;
 const dec=Number($("decoration").value)||0;
 const hallCost=h?h.price:0;
 $("sumHall").textContent=h?h.name:"-";
 $("hallPrice").textContent=money(hallCost);
 $("chairPrice").textContent=money(chairs*chairRate);
 $("decPrice").textContent=money(dec);
 $("total").textContent=money(hallCost+chairs*chairRate+dec);
}
["hall","date","eventType","guests","chairs","decoration"].forEach(id=>$(id).addEventListener("input",update));
$("bookingForm").addEventListener("submit",e=>{
 e.preventDefault();
 const h=halls.find(x=>x.id===$("hall").value);
 const date=$("date").value, guests=Number($("guests").value), chairs=Number($("chairs").value);
 if(!h||!date||!$("eventType").value)return;
 if(guests>h.capacity){alert("Guest count exceeds this hall's capacity.");return}
 if(chairs>h.chairs){alert("Requested chairs exceed available chairs.");return}
 const total=(h.price)+(chairs*chairRate)+Number($("decoration").value);
 $("paymentBox").innerHTML=`<h3>Pay ${money(total)}</h3><p class="small">Demo payment screen. No real money is charged.</p>
 <div class="payment-options"><div class="pay-option active" data-method="UPI">UPI</div><div class="pay-option" data-method="Card">Card</div><div class="pay-option" data-method="Net Banking">Net Banking</div></div>
 <div id="upi"><label>UPI ID<input id="upiId" placeholder="example@upi"></label></div>
 <button class="btn" id="payBtn">Pay ${money(total)}</button>`;
 document.querySelectorAll(".pay-option").forEach(x=>x.onclick=()=>{document.querySelectorAll(".pay-option").forEach(y=>y.classList.remove("active"));x.classList.add("active")});
 $("payBtn").onclick=()=>{
   const bookingId="FH"+Date.now().toString().slice(-8);
   $("bookingResult").className="result success";
   $("bookingResult").innerHTML=`<h3>Booking Confirmed ✓</h3><p><b>Booking ID:</b> ${bookingId}</p><p><b>Hall:</b> ${h.name}</p><p><b>Date:</b> ${date}</p><p><b>Event:</b> ${$("eventType").value}</p><p><b>Guests:</b> ${guests}</p><p><b>Chairs:</b> ${chairs}</p><p><b>Total paid:</b> ${money(total)}</p>`;
   alert("Demo payment successful. Booking confirmed!");
 };
 location.hash="payments";
});
const today=new Date().toISOString().split("T")[0];$("date").min=today;
renderHalls();update();
